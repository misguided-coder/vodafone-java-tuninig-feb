import java.util.*;

public class OOMOverHeadLimit {

    List<Employee> list = new ArrayList<Employee>();

    public static void main(String args[]) throws Exception {
	new OOMOverHeadLimit();
    }		

   public OOMOverHeadLimit() {
	for(;;) {
		Employee emp = new Employee("Raj");	 		
		list.add(new Employee("Rohan"));
		emp = null;
	}		

    }

}


class Employee {
	
	String name;

	public Employee(String name) {
		this.name = name;
	}

	public String toString() {
		return "Name : "+this.name;
	}

}

