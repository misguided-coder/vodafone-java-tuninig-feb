import java.util.*;

public class OOMExample {

    public static void main(String args[]) throws Exception {
	
	for(;;) {
		Employee emp=new Employee("Rohan");		
		System.out.println(emp);
		emp = null; 	 		
	}		

    }

}


class Employee {
	
	String name;

	public Employee(String name) {
		this.name = name;
	}

	public String toString() {
		return "Name : "+this.name;
	}

	@Override
	protected void finalize() {
		System.out.println("Employee is being finalized!!");
		try{
			Thread.sleep(2000);	
		}catch(Exception e){}
	}	

}

