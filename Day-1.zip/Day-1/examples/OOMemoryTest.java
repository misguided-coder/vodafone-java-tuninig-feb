import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class OOMemoryTest {
	
	List<String> memoryEater = new ArrayList<>();
		
	public static void main(String[] args) throws Exception  {

		new OOMemoryTest();	
		System.out.println("Finish Border Line!!!!!");
	}
	
	public OOMemoryTest() throws Exception {
		for(int i=0;i<999999999;i++) {
			memoryEater.add(new String("Memory is going to finish soon, save it - "+i));			
			TimeUnit.SECONDS.sleep(1);
			System.out.println("Adding string object in memory!!!!!");
		}
		
	}

}
